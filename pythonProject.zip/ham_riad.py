def parity_generator(parity_pos, mess):
    k = 0
    x = []
    i = parity_pos
    while i <= len(mess):
        if k < parity_pos:
            x.append(mess[i - 1])
            k = k + 1
        else:
            k = 0
            i = i + parity_pos - 1
        i = i + 1
    add = 0
    for j in x:
        if j != '?':
            add = add + int(j)
    if add%2:
        return 1
    else:
        return 0


parity_pos = []
for i in range(5):
    parity_pos.append(2**i)

mess = "1011001"

mess = [i for i in mess]
print("message: ", mess)
for i in range(1,6):
    l = len(mess) + i
    if l <= parity_pos[i-1]:
        break
parity = i-1

for i in range(0, parity):
    mess.insert(parity_pos[i] - 1, '?')

print('Message with Parity position:',mess)
for i in parity_pos:
    if i < len(mess):
        mess[i-1] = parity_generator(i, mess)
    else:
        break

print('Message with Parity position:', mess)
